package sahilkr.mytodoapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mytodoapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskClickListener {
    private DatabaseHelper dbHelper;
    private TaskAdapter adapter;
    private List<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DatabaseHelper(this);
        taskList = dbHelper.getAllTasks();

        RecyclerView recyclerView = findViewById(R.id.recyclerViewTasks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(taskList, this);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAddTask);
        fab.setOnClickListener(v -> showAddTaskDialog());
    }

    @Override
    public void onTaskClick(Task task) {
        showEditTaskDialog(task);
    }

    @Override
    public void onTaskCheckedChanged(Task task, boolean isChecked) {
        task.setCompleted(isChecked);
        dbHelper.updateTask(task);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onPriorityClick(Task task) {
        showPriorityDialog(task);
    }

    @Override
    public void onDeleteClick(Task task) {
        new AlertDialog.Builder(this)
            .setTitle("Delete Task")
            .setMessage("Are you sure you want to delete this task?")
            .setPositiveButton("Delete", (dialog, which) -> {
                dbHelper.deleteTask(task.getId());
                taskList.remove(task);
                adapter.notifyDataSetChanged();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showAddTaskDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_task, null);
        EditText editTextTitle = dialogView.findViewById(R.id.editTextTitle);
        EditText editTextDescription = dialogView.findViewById(R.id.editTextDescription);
        RadioGroup radioGroupPriority = dialogView.findViewById(R.id.radioGroupPriority);
        TextView textViewDueDate = dialogView.findViewById(R.id.textViewDueDate);

        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, day) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
            textViewDueDate.setText(dateFormat.format(calendar.getTime()));
        };

        textViewDueDate.setOnClickListener(v -> {
            new DatePickerDialog(this, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        new AlertDialog.Builder(this)
            .setTitle("Add New Task")
            .setView(dialogView)
            .setPositiveButton("Add", (dialog, which) -> {
                String title = editTextTitle.getText().toString();
                String description = editTextDescription.getText().toString();
                int priority = getPriorityFromRadioGroup(radioGroupPriority);
                Date dueDate = calendar.getTime();

                Task newTask = new Task(title, description, priority, dueDate);
                long id = dbHelper.addTask(newTask);
                newTask.setId(id);
                taskList.add(newTask);
                adapter.notifyDataSetChanged();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showEditTaskDialog(Task task) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_task, null);
        EditText editTextTitle = dialogView.findViewById(R.id.editTextTitle);
        EditText editTextDescription = dialogView.findViewById(R.id.editTextDescription);
        RadioGroup radioGroupPriority = dialogView.findViewById(R.id.radioGroupPriority);
        TextView textViewDueDate = dialogView.findViewById(R.id.textViewDueDate);

        editTextTitle.setText(task.getTitle());
        editTextDescription.setText(task.getDescription());
        setPriorityInRadioGroup(radioGroupPriority, task.getPriority());

        Calendar calendar = Calendar.getInstance();
        if (task.getDueDate() != null) {
            calendar.setTime(task.getDueDate());
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
            textViewDueDate.setText(dateFormat.format(task.getDueDate()));
        }

        DatePickerDialog.OnDateSetListener dateSetListener = (view, year, month, day) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
            textViewDueDate.setText(dateFormat.format(calendar.getTime()));
        };

        textViewDueDate.setOnClickListener(v -> {
            new DatePickerDialog(this, dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        new AlertDialog.Builder(this)
            .setTitle("Edit Task")
            .setView(dialogView)
            .setPositiveButton("Save", (dialog, which) -> {
                task.setTitle(editTextTitle.getText().toString());
                task.setDescription(editTextDescription.getText().toString());
                task.setPriority(getPriorityFromRadioGroup(radioGroupPriority));
                task.setDueDate(calendar.getTime());
                dbHelper.updateTask(task);
                adapter.notifyDataSetChanged();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showPriorityDialog(Task task) {
        String[] priorities = {"Low", "Medium", "High"};
        new AlertDialog.Builder(this)
            .setTitle("Set Priority")
            .setItems(priorities, (dialog, which) -> {
                task.setPriority(which);
                dbHelper.updateTask(task);
                adapter.notifyDataSetChanged();
            })
            .show();
    }

    private int getPriorityFromRadioGroup(RadioGroup radioGroup) {
        int checkedId = radioGroup.getCheckedRadioButtonId();
        if (checkedId == R.id.radioButtonLow) return 0;
        if (checkedId == R.id.radioButtonMedium) return 1;
        if (checkedId == R.id.radioButtonHigh) return 2;
        return 0;
    }

    private void setPriorityInRadioGroup(RadioGroup radioGroup, int priority) {
        switch (priority) {
            case 0:
                radioGroup.check(R.id.radioButtonLow);
                break;
            case 1:
                radioGroup.check(R.id.radioButtonMedium);
                break;
            case 2:
                radioGroup.check(R.id.radioButtonHigh);
                break;
        }
    }
}