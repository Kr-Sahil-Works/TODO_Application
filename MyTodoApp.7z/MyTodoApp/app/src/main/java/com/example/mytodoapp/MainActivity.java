package com.example.mytodoapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.example.mytodoapp.R;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskClickListener {
    private DatabaseHelper dbHelper;
    private TaskAdapter adapter;
    private List<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        taskList = dbHelper.getAllTasks();

        RecyclerView recyclerView = findViewById(R.id.recyclerViewTasks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(taskList, this);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAddTask);
        fab.setOnClickListener(v -> showAddTaskDialog());
    }

    private void showAddTaskDialog() {
        showTaskDialog(null);
    }

    private void showTaskDialog(Task task) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_task, null);
        EditText editTextTitle = dialogView.findViewById(R.id.editTextTitle);
        EditText editTextDescription = dialogView.findViewById(R.id.editTextDescription);
        RadioGroup radioGroupPriority = dialogView.findViewById(R.id.radioGroupPriority);
        TextView textViewDueDate = dialogView.findViewById(R.id.textViewDueDate);
        View buttonSetDueDate = dialogView.findViewById(R.id.buttonSetDueDate);

        Date[] selectedDate = new Date[1];
        if (task != null) {
            editTextTitle.setText(task.getTitle());
            editTextDescription.setText(task.getDescription());
            switch (task.getPriority()) {
                case 0:
                    radioGroupPriority.check(R.id.radioButtonLow);
                    break;
                case 1:
                    radioGroupPriority.check(R.id.radioButtonMedium);
                    break;
                case 2:
                    radioGroupPriority.check(R.id.radioButtonHigh);
                    break;
            }
            if (task.getDueDate() != null) {
                selectedDate[0] = task.getDueDate();
                textViewDueDate.setText(new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                        .format(task.getDueDate()));
            }
        }

        buttonSetDueDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            if (selectedDate[0] != null) {
                calendar.setTime(selectedDate[0]);
            }

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this,
                    (view, year, month, dayOfMonth) -> {
                        calendar.set(year, month, dayOfMonth);
                        selectedDate[0] = calendar.getTime();
                        textViewDueDate.setText(new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                                .format(selectedDate[0]));
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(task == null ? "Add Task" : "Edit Task")
                .setView(dialogView)
                .setPositiveButton("Save", (dialogInterface, i) -> {
                    String title = editTextTitle.getText().toString().trim();
                    if (title.isEmpty()) {
                        Toast.makeText(this, "Title cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int priority = 0;
                    int checkedId = radioGroupPriority.getCheckedRadioButtonId();
                    if (checkedId == R.id.radioButtonMedium) priority = 1;
                    else if (checkedId == R.id.radioButtonHigh) priority = 2;

                    if (task == null) {
                        Task newTask = new Task(title, editTextDescription.getText().toString(),
                                priority, selectedDate[0]);
                        long id = dbHelper.addTask(newTask);
                        newTask.setId(id);
                        taskList.add(newTask);
                    } else {
                        task.setTitle(title);
                        task.setDescription(editTextDescription.getText().toString());
                        task.setPriority(priority);
                        task.setDueDate(selectedDate[0]);
                        dbHelper.updateTask(task);
                    }
                    adapter.updateTasks(taskList);
                })
                .setNegativeButton("Cancel", null)
                .create();

        dialog.show();
    }

    @Override
    public void onTaskClick(Task task) {
        showTaskDialog(task);
    }

    @Override
    public void onTaskCheckedChanged(Task task, boolean isChecked) {
        dbHelper.updateTask(task);
    }

    @Override
    public void onPriorityClick(Task task) {
        String[] priorities = {"Low", "Medium", "High"};
        new AlertDialog.Builder(this)
                .setTitle("Set Priority")
                .setItems(priorities, (dialog, which) -> {
                    task.setPriority(which);
                    dbHelper.updateTask(task);
                    adapter.updateTasks(taskList);
                })
                .show();
    }

    @Override
    public void onDeleteClick(Task task) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Task")
                .setMessage("Are you sure you want to delete this task?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    dbHelper.deleteTask(task.getId());
                    taskList.remove(task);
                    adapter.updateTasks(taskList);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
} 