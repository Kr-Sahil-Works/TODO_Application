package com.example.mytodoapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "TodoDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_TASKS = "tasks";

    // Column names
    private static final String KEY_ID = "id";
    private static final String KEY_TITLE = "title";
    private static final String KEY_DESCRIPTION = "description";
    private static final String KEY_COMPLETED = "completed";
    private static final String KEY_PRIORITY = "priority";
    private static final String KEY_DUE_DATE = "due_date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TASKS_TABLE = "CREATE TABLE " + TABLE_TASKS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_TITLE + " TEXT,"
                + KEY_DESCRIPTION + " TEXT,"
                + KEY_COMPLETED + " INTEGER,"
                + KEY_PRIORITY + " INTEGER,"
                + KEY_DUE_DATE + " INTEGER"
                + ")";
        db.execSQL(CREATE_TASKS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
        onCreate(db);
    }

    // Add a new task
    public long addTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, task.getTitle());
        values.put(KEY_DESCRIPTION, task.getDescription());
        values.put(KEY_COMPLETED, task.isCompleted() ? 1 : 0);
        values.put(KEY_PRIORITY, task.getPriority());
        if (task.getDueDate() != null) {
            values.put(KEY_DUE_DATE, task.getDueDate().getTime());
        }

        long id = db.insert(TABLE_TASKS, null, values);
        db.close();
        return id;
    }

    // Get a single task
    public Task getTask(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TASKS, null, KEY_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        Task task = null;
        if (cursor != null && cursor.moveToFirst()) {
            task = cursorToTask(cursor);
            cursor.close();
        }
        db.close();
        return task;
    }

    // Get all tasks
    public List<Task> getAllTasks() {
        List<Task> taskList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_TASKS + " ORDER BY " + KEY_PRIORITY + " DESC";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Task task = cursorToTask(cursor);
                taskList.add(task);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return taskList;
    }

    // Update a task
    public int updateTask(Task task) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, task.getTitle());
        values.put(KEY_DESCRIPTION, task.getDescription());
        values.put(KEY_COMPLETED, task.isCompleted() ? 1 : 0);
        values.put(KEY_PRIORITY, task.getPriority());
        if (task.getDueDate() != null) {
            values.put(KEY_DUE_DATE, task.getDueDate().getTime());
        }

        int result = db.update(TABLE_TASKS, values, KEY_ID + " = ?",
                new String[]{String.valueOf(task.getId())});
        db.close();
        return result;
    }

    // Delete a task
    public void deleteTask(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_TASKS, KEY_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
    }

    // Helper method to convert cursor to Task object
    private Task cursorToTask(Cursor cursor) {
        Task task = new Task();
        task.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
        task.setTitle(cursor.getString(cursor.getColumnIndex(KEY_TITLE)));
        task.setDescription(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)));
        task.setCompleted(cursor.getInt(cursor.getColumnIndex(KEY_COMPLETED)) == 1);
        task.setPriority(cursor.getInt(cursor.getColumnIndex(KEY_PRIORITY)));
        
        long dueDate = cursor.getLong(cursor.getColumnIndex(KEY_DUE_DATE));
        if (dueDate > 0) {
            task.setDueDate(new Date(dueDate));
        }
        
        return task;
    }
} 