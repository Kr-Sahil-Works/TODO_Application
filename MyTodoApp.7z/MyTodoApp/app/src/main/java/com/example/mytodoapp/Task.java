package com.example.mytodoapp;

import java.util.Date;

public class Task {
    private long id;
    private String title;
    private String description;
    private boolean isCompleted;
    private int priority;
    private Date dueDate;

    public Task() {
        this.isCompleted = false;
        this.priority = 0; // 0: Low, 1: Medium, 2: High
    }

    public Task(String title, String description, int priority, Date dueDate) {
        this.title = title;
        this.description = description;
        this.isCompleted = false;
        this.priority = priority;
        this.dueDate = dueDate;
    }

    // Getters and Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public boolean isCompleted() { return isCompleted; }
    public void setCompleted(boolean completed) { isCompleted = completed; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }
} 